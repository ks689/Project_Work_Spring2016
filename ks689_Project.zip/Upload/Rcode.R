library(jsonlite)
library(MASS)
library(C50)



json <- fromJSON("C:\\Users\\Aejaj\\Desktop\\KaggleData\\trainjson\\train.json", flatten = TRUE)
jsonNew=json[-c(7,12)]

for(i in 1:length(jsonNew))
{
  assign(paste("a", i, sep = ""), unlist(jsonNew[i], use.names = FALSE))
}
dataFrameFinal=data.frame("bathrooms"=a1,"bedrooms"=a2,"building_id"=a3,"created"=a4,"description"=a5,"display_address"=a6,"latitude"=a7,"listing_id"=a8,"longitude"=a9,"manager_id"=a10,"price"=a11,"street_address"=a12,"interest_level"=a13)

dfTrain = data.frame(Swimming_Pool = character(),
                     Roof_Deck = character(),
                     Dining_Room = character(),
                     Doorman = character(),
                     Elevator = character(),
                     Fitness_Center = character(),
                     Terrace = character(),
                     Laundry_in_Building= character(),
                     Laundry_in_Unit = character(),
                     High_Speed_Internet = character(),
                     Dishwasher = character(),
                     Hardwood_Floors = character(),
                     Wheelchair_Access = character(),
                     No_Fee = character(),
                     Outdoor_Space= character(),
                     New_Construction = character(),
                     Dogs_Allowed = character(), 
                     Cats_Allowed = character(),
                     Pre_War = character(),
                     Garden_Patio = character(),
                     Private_Outdoor_Space = character(),
                     interestLevel = character(), 
                     stringsAsFactors = FALSE)


for(i in 1 : 49352)
{
  if('Swimming Pool' %in% unlist(json$features[[i]]) )
    feat_sp = 'yes'
  else
    feat_sp = 'no'
  if('Roof Deck' %in% unlist(json$features[[i]]) )
    feat_rd = 'yes'
  else
    feat_rd = 'no'
  if('Dining Room' %in% unlist(json$features[[i]]) )
    feat_dr = 'yes'
  else
    feat_dr = 'no'
  if('Doorman' %in% unlist(json$features[[i]]) )
    feat_dm = 'yes'
  else
    feat_dm = 'no'
  if('Elevator' %in% unlist(json$features[[i]]) )
    feat_ele = 'yes'
  else
    feat_ele = 'no'
  if('Fitness Center' %in% unlist(json$features[[i]]) )
    feat_fc = 'yes'
  else
    feat_fc = 'no'
  if('Terrace' %in% unlist(json$features[[i]]) )
    feat_ter = 'yes'
  else
    feat_ter = 'no'
  if('Laundry in Building' %in% unlist(json$features[[i]]) )
    feat_lib = 'yes'
  else
    feat_lib = 'no'
  if('Laundry in Unit' %in% unlist(json$features[[i]]) )
    feat_liu = 'yes'
  else
    feat_liu = 'no'
  if('High Speed Internet' %in% unlist(json$features[[i]]) )
    feat_int = 'yes'
  else
    feat_int = 'no'
  if('Dishwasher' %in% unlist(json$features[[i]]) )
    feat_dw = 'yes'
  else
    feat_dw = 'no'
  if('No Fee' %in% unlist(json$features[[i]]) )
    feat_nf = 'yes'
  else
    feat_nf = 'no'
  if('Wheelchair Access' %in% unlist(json$features[[i]]) )
    feat_wa = 'yes'
  else
    feat_wa = 'no'
  if('Hardwood Floors' %in% unlist(json$features[[i]]) )
    feat_hf = 'yes'
  else
    feat_hf = 'no'	
  if('Dogs Allowed' %in% unlist(json$features[[i]]) )
    feat_dog = 'yes'
  else
    feat_dog = 'no'
  if('New Construction' %in% unlist(json$features[[i]]) )
    feat_nc = 'yes'
  else
    feat_nc = 'no'
  if('Outdoor Space' %in% unlist(json$features[[i]]) )
    feat_os = 'yes'
  else
    feat_os = 'no'
  if('Cats Allowed' %in% unlist(json$features[[i]]) )
    feat_cat = 'yes'
  else
    feat_cat = 'no'
  if('Pre-War' %in% unlist(json$features[[i]]) )
    feat_pw = 'yes'
  else
    feat_pw = 'no'
  if('Private Outdoor Space' %in% unlist(json$features[[i]]) )
    feat_pos = 'yes'
  else
    feat_pos = 'no'
  if('Garden/Patio'  %in% unlist(json$features[[i]]) )
    feat_gp	= 'yes'
  else
    feat_gp = 'no'
  dfTrain = rbind(dfTrain, data.frame( feat_sp , feat_rd , feat_dr, feat_dm, feat_ele, feat_fc, feat_ter, feat_lib, feat_liu, feat_int, feat_dw, feat_hf, feat_wa, feat_nf, feat_os, 
                                       feat_nc, feat_dog, feat_cat, feat_pw, feat_gp, feat_pos))
}


# Chi square test of independance for features as categorical variables
library(MASS)

a=chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_sp))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_rd))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_dr))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_dm))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_ele))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_fc))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_ter))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_lib))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_liu))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_int))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_dw))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_hf))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_wa))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_nf))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_os))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_nc))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_dog))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_cat))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_pw))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_gp))
chisq.test(table(dfTrain$unlist.json.interest_level..i..., dfTrain$feat_pos))



dfTrain = read.csv(file = "C:\\Users\\Aejaj\\Desktop\\KaggleData\\Data.csv" ,header=TRUE)
photo_count=list()
photo_dc=list()
feature_count=list()
feature_dc=list()
for(i in 1:length(json$photos)){
  if(!(is.null(length(unlist(json$photos[i]))))){
    photo_count[[i]]=length(unlist(json$photos[i]))
    photo_dc[[i]]=1
  } else{
    photo_count[[i]]=0
    photo_dc[[i]]=0
  }
}
for(i in 1:length(json$features)){
  if(!(is.null(length(unlist(json$features[i]))))){
    feature_count[[i]]=length(unlist(json$features[i]))
    feature_dc[[i]]=1              
  } else{
    feature_count[[i]]=0
    feature_dc[[i]]=0 
  }
}

cr_date=c()

for(i in 1:length(json$created)){
  cr_date=c(cr_date,as.Date(json$created[[i]], origin="1970-01-01"))
}
class(cr_date)="Date"
#current system time 
end_time=as.Date(Sys.time(), origin="1970-01-01")

created_since=c()
a=c()
b=c()
#time difference in days
for(i in 1:length(json$created)){
  
  a[i]=difftime(end_time,cr_date[i], units = "days")
  b[i]=grep("[0-9]*",a[i],value = TRUE)
  created_since=c(created_since, b[i])
}

dfTrain=cbind(dataFrameFinal, dfTrain)

dataFrameFinal4=cbind(dfTrain[1:2],dfTrain[7],dfTrain[9],dfTrain[11],"photo_dc"=unlist(photo_dc),"feature_count"=unlist(feature_count),dfTrain[14:34],"created"=created_since,dfTrain[13])

targetString <- as.formula(paste('interest_level ~ ' ,paste(names(dataFrameFinal4[-30]),collapse='+')))

library(randomForest)
trainedRandomModel <- randomForest(targetString,dataFrameFinal4)
tree1 <- C50::C5.0(dataFrameFinal4[,-30],dataFrameFinal4[,30])

jsontest <- fromJSON("C:\\Users\\Aejaj\\Desktop\\KaggleData\\test.json\\test.json", flatten = TRUE)
jsonNewtest=jsontest[-c(7,12)]

for(i in 1:length(jsonNewtest))
{
  assign(paste("b", i, sep = ""), unlist(jsonNewtest[i], use.names = FALSE))
}
dataFrameFinaltest=data.frame("bathrooms"=b1,"bedrooms"=b2,"building_id"=b3,"created"=b4,"description"=b5,"display_address"=b6,"latitude"=b7,"listing_id"=b8,"longitude"=b9,"manager_id"=b10,"price"=b11,"street_address"=b12)

dfTest = data.frame(Swimming_Pool = character(),
                    Roof_Deck = character(),
                    Dining_Room = character(),
                    Doorman = character(),
                    Elevator = character(),
                    Fitness_Center = character(),
                    Terrace = character(),
                    Laundry_in_Building= character(),
                    Laundry_in_Unit = character(),
                    High_Speed_Internet = character(),
                    Dishwasher = character(),
                    Hardwood_Floors = character(),
                    Wheelchair_Access = character(),
                    No_Fee = character(),
                    Outdoor_Space= character(),
                    New_Construction = character(),
                    Dogs_Allowed = character(), 
                    Cats_Allowed = character(),
                    Pre_War = character(),
                    Garden_Patio = character(),
                    Private_Outdoor_Space = character(),
                    interestLevel = character(), 
                    stringsAsFactors = FALSE)
for(i in 1 : length(jsonNewtest[[2]]))
{
  if('Swimming Pool' %in% unlist(jsontest$features[[i]]) )
    feat_sp = 'yes'
  else
    feat_sp = 'no'
  if('Roof Deck' %in% unlist(jsontest$features[[i]]) )
    feat_rd = 'yes'
  else
    feat_rd = 'no'
  if('Dining Room' %in% unlist(jsontest$features[[i]]) )
    feat_dr = 'yes'
  else
    feat_dr = 'no'
  if('Doorman' %in% unlist(jsontest$features[[i]]) )
    feat_dm = 'yes'
  else
    feat_dm = 'no'
  if('Elevator' %in% unlist(jsontest$features[[i]]) )
    feat_ele = 'yes'
  else
    feat_ele = 'no'
  if('Fitness Center' %in% unlist(jsontest$features[[i]]) )
    feat_fc = 'yes'
  else
    feat_fc = 'no'
  if('Terrace' %in% unlist(jsontest$features[[i]]) )
    feat_ter = 'yes'
  else
    feat_ter = 'no'
  if('Laundry in Building' %in% unlist(jsontest$features[[i]]) )
    feat_lib = 'yes'
  else
    feat_lib = 'no'
  if('Laundry in Unit' %in% unlist(jsontest$features[[i]]) )
    feat_liu = 'yes'
  else
    feat_liu = 'no'
  if('High Speed Internet' %in% unlist(jsontest$features[[i]]) )
    feat_int = 'yes'
  else
    feat_int = 'no'
  if('Dishwasher' %in% unlist(jsontest$features[[i]]) )
    feat_dw = 'yes'
  else
    feat_dw = 'no'
  if('No Fee' %in% unlist(jsontest$features[[i]]) )
    feat_nf = 'yes'
  else
    feat_nf = 'no'
  if('Wheelchair Access' %in% unlist(jsontest$features[[i]]) )
    feat_wa = 'yes'
  else
    feat_wa = 'no'
  if('Hardwood Floors' %in% unlist(jsontest$features[[i]]) )
    feat_hf = 'yes'
  else
    feat_hf = 'no'	
  if('Dogs Allowed' %in% unlist(jsontest$features[[i]]) )
    feat_dog = 'yes'
  else
    feat_dog = 'no'
  if('New Construction' %in% unlist(jsontest$features[[i]]) )
    feat_nc = 'yes'
  else
    feat_nc = 'no'
  if('Outdoor Space' %in% unlist(jsontest$features[[i]]) )
    feat_os = 'yes'
  else
    feat_os = 'no'
  if('Cats Allowed' %in% unlist(jsontest$features[[i]]) )
    feat_cat = 'yes'
  else
    feat_cat = 'no'
  if('Pre-War' %in% unlist(jsontest$features[[i]]) )
    feat_pw = 'yes'
  else
    feat_pw = 'no'
  if('Private Outdoor Space' %in% unlist(jsontest$features[[i]]) )
    feat_pos = 'yes'
  else
    feat_pos = 'no'
  if('Garden/Patio'  %in% unlist(jsontest$features[[i]]) )
    feat_gp	= 'yes'
  else
    feat_gp = 'no'
  dfTest = rbind(dfTest, data.frame( feat_sp , feat_rd , feat_dr, feat_dm, feat_ele, feat_fc, feat_ter, feat_lib, feat_liu, feat_int, feat_dw, feat_hf, feat_wa, feat_nf, feat_os, 
                                     feat_nc, feat_dog, feat_cat, feat_pw, feat_gp, feat_pos))
}
dfTest = read.csv(file = "C:\\Users\\Aejaj\\Desktop\\KaggleData\\testData.csv" ,header=TRUE)
dfTest=cbind(dataFrameFinaltest, dfTest)

photo_count=list()
photo_dc=list()
feature_count=list()
feature_dc=list()
for(i in 1:length(jsontest$photos)){
  if(!(is.null(length(unlist(jsontest$photos[i]))))){
    photo_count[[i]]=length(unlist(jsontest$photos[i]))
    photo_dc[[i]]=1
  } else{
    photo_count[[i]]=0
    photo_dc[[i]]=0
  }
}
for(i in 1:length(jsontest$features)){
  if(!(is.null(length(unlist(jsontest$features[i]))))){
    feature_count[[i]]=length(unlist(jsontest$features[i]))
    feature_dc[[i]]=1              
  } else{
    feature_count[[i]]=0
    feature_dc[[i]]=0 
  }
}
cr_date=c()

for(i in 1:length(jsontest$created)){
  cr_date=c(cr_date,as.Date(jsontest$created[[i]], origin="1970-01-01"))
}
class(cr_date)="Date"
#current system time 
end_time=as.Date(Sys.time(), origin="1970-01-01")

created_since=c()
a=c()
b=c()
#time difference in days
for(i in 1:length(jsontest$created)){
  
  a[i]=difftime(end_time,cr_date[i], units = "days")
  b[i]=grep("[0-9]*",a[i],value = TRUE)
  created_since=c(created_since, b[i])
}

dataFrameFinaltest2=cbind(dfTest[1:2],dfTest[7],dfTest[9],dfTest[11],"photo_dc"=unlist(photo_dc),"feature_count"=unlist(feature_count),dfTest[13:33],"created"=created_since)

pred<-predict(tree1 , dataFrameFinaltest2 ,type = "prob")
submission=data.frame(dataFrameFinaltest$listing_id,pred)
write.csv(submission,"C:\\Users\\Aejaj\\Desktop\\KaggleData\\Submission.csv")