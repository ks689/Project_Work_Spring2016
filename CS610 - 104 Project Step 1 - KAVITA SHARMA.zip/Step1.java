
public class Step1 {

	public static void main(String[] args){
		
//		System.gc();
		String matStrA = "-5r4c4,5r1c4,2r2c2,5r3c1,-3r3c2,6r4c2,-7r2c3,3r1c1";
		String matStrB = "1r4c4,1r3c3,1r2c6,1r4c1,1r2c2,1r1c5,1r1c1";
			
		SparseMatrix matA= new SparseMatrix(matStrA);
		SparseMatrix matB= new SparseMatrix(matStrB);
	    SparseMatrix matC= new SparseMatrix(5, 6, "C");
		SparseMatrix matD= new SparseMatrix(6, 5, "D");
		SparseMatrix matE=new SparseMatrix(200, 200, "E");
		SparseMatrix matF=new SparseMatrix(200, 1, "F");
	    SparseMatrix matG=new SparseMatrix(30000, 30000, "G");
		
		System.out.println("Matrix A is :");
		matA.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Matrix B is : ");
		matB.print();
		System.out.println();
		System.out.println();
				
		System.out.println("Matrix C is : ");
		matC.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Matrix D is : ");
		matD.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Matrix E is : ");
		matE.print();
		System.out.println();
		System.out.println();		
		
		System.out.println("Matrix F is : ");
		matF.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Matrix G is : ");
		matG.print();
		System.out.println(matG.getArray().length);
		System.out.println();
		
		
		System.out.println("Matrix A is equal to Matrix A" + " : " +matA.equals(matA));
		System.out.println("Matrix A is equal to Matrix B" + " : " +matA.equals(matB));
		System.out.println("Matrix A is equal to Matrix C" + " : " +matA.equals(matC));
		System.out.println("Matrix A is equal to Matrix D" + " : " +matA.equals(matD));
		System.out.println("Matrix A is equal to Matrix E" + " : " +matA.equals(matE));
		System.out.println("Matrix A is equal to Matrix F" + " : " +matA.equals(matF));
		System.out.println("Matrix A is equal to Matrix G" + " : " +matA.equals(matG));
		
		System.out.println();
		System.out.println("Matrix B is equal to Matrix A" + " : " +matB.equals(matA));
		System.out.println("Matrix B is equal to Matrix B" + " : " +matB.equals(matB));
		System.out.println("Matrix B is equal to Matrix C" + " : " +matB.equals(matC));
		System.out.println("Matrix B is equal to Matrix D" + " : " +matB.equals(matD));
		System.out.println("Matrix B is equal to Matrix E" + " : " +matB.equals(matE));
		System.out.println("Matrix B is equal to Matrix F" + " : " +matB.equals(matF));
		System.out.println("Matrix B is equal to Matrix G" + " : " +matB.equals(matG));
		
		System.out.println();
		System.out.println("Matrix C is equal to Matrix A" + " : " +matC.equals(matA));
		System.out.println("Matrix C is equal to Matrix B" + " : " +matC.equals(matB));
		System.out.println("Matrix C is equal to Matrix C" + " : " +matC.equals(matC));
		System.out.println("Matrix C is equal to Matrix D" + " : " +matC.equals(matD));
		System.out.println("Matrix C is equal to Matrix E" + " : " +matC.equals(matE));
		System.out.println("Matrix C is equal to Matrix F" + " : " +matC.equals(matF));
		System.out.println("Matrix C is equal to Matrix G" + " : " +matC.equals(matG));
		
		System.out.println();
		System.out.println("Matrix D is equal to Matrix A" + " : " +matD.equals(matA));
		System.out.println("Matrix D is equal to Matrix B" + " : " +matD.equals(matB));
		System.out.println("Matrix D is equal to Matrix C" + " : " +matD.equals(matC));
		System.out.println("Matrix D is equal to Matrix D" + " : " +matD.equals(matD));
		System.out.println("Matrix D is equal to Matrix E" + " : " +matD.equals(matE));
		System.out.println("Matrix D is equal to Matrix F" + " : " +matD.equals(matF));
		System.out.println("Matrix D is equal to Matrix G" + " : " +matD.equals(matG));
		
		System.out.println();
		System.out.println("Matrix E is equal to Matrix A" + " : " +matE.equals(matA));
		System.out.println("Matrix E is equal to Matrix B" + " : " +matE.equals(matB));
		System.out.println("Matrix E is equal to Matrix C" + " : " +matE.equals(matC));
		System.out.println("Matrix E is equal to Matrix D" + " : " +matE.equals(matD));
		System.out.println("Matrix E is equal to Matrix E" + " : " +matE.equals(matE));
		System.out.println("Matrix E is equal to Matrix F" + " : " +matE.equals(matF));
		System.out.println("Matrix E is equal to Matrix G" + " : " +matE.equals(matG));
		
		System.out.println();
		System.out.println("Matrix F is equal to Matrix A" + " : " +matF.equals(matA));
		System.out.println("Matrix F is equal to Matrix B" + " : " +matF.equals(matB));
		System.out.println("Matrix F is equal to Matrix C" + " : " +matF.equals(matC));
		System.out.println("Matrix F is equal to Matrix D" + " : " +matF.equals(matD));
		System.out.println("Matrix F is equal to Matrix E" + " : " +matF.equals(matE));
		System.out.println("Matrix F is equal to Matrix F" + " : " +matF.equals(matF));
		System.out.println("Matrix F is equal to Matrix G" + " : " +matF.equals(matG));
		
		System.out.println();
		System.out.println("Matrix G is equal to Matrix A" + " : " +matG.equals(matA));
		System.out.println("Matrix G is equal to Matrix B" + " : " +matG.equals(matB));
		System.out.println("Matrix G is equal to Matrix C" + " : " +matG.equals(matC));
		System.out.println("Matrix G is equal to Matrix D" + " : " +matG.equals(matD));
		System.out.println("Matrix G is equal to Matrix E" + " : " +matG.equals(matE));
		System.out.println("Matrix G is equal to Matrix F" + " : " +matG.equals(matF));
		System.out.println("Matrix G is equal to Matrix G" + " : " +matG.equals(matG));
		
		System.out.println("Scalar Multiply of A ");
		SparseMatrix a = new SparseMatrix(4, 4);
		a.setArray(matA.scalarMultiply(5));
		a.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Scalar Multiply of B ");
		SparseMatrix b = new SparseMatrix(4, 6);
		b.setArray(matB.scalarMultiply(5));
		b.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Scalar Multiply of C ");
		SparseMatrix c = new SparseMatrix(5, 6);
		c.setArray(matC.scalarMultiply(5));
		c.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Scalar Multiply of D");
		SparseMatrix d = new SparseMatrix(6, 5);
		d.setArray(matD.scalarMultiply(5));
		d.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Scalar Multiply of E");
		SparseMatrix e = new SparseMatrix(200, 200);
		e.setArray(matE.scalarMultiply(5));
		e.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Scalar Multiply of F");
		SparseMatrix f = new SparseMatrix(200, 1);
		f.setArray(matF.scalarMultiply(5));
		f.print();
		System.out.println();
		System.out.println();
		
//		System.out.print("Scalar Multiply of G");
//		SparseMatrix g = new SparseMatrix(30000, 30000);
//		g.setArray(matG.scalarMultiply(5));
//		g.print();
//		System.out.println();
//		System.out.println();
//		
		
	}

}
