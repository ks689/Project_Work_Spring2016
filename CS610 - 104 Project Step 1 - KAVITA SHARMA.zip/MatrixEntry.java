public class MatrixEntry {
    
    private int value;
    
    private int row;
    private int col;
    
    private int conCatVal;
    
    public int getConCatVal() {
		return conCatVal;
			}

	public void setConCatVal(int conCatVal) {
		this.conCatVal = conCatVal;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public void setCol(int col) {
		this.col = col;
	}

	public int getValue() {
		return value;
	}

	public int getRow() {
		return row;
	}

	public int getCol() {
		return col;
	}

	public MatrixEntry(int value, int row, int col) {
        this.value = value;
        this.row = row;
        this.col =  col;
        //this.conCatVal= conCat(row, col);
    }
	
	public int conCat(Integer row, Integer col){
		String addJoin= row.toString() + col.toString();
		return Integer.parseInt(addJoin);
	}

    // TODO: Getters and setters?
}
