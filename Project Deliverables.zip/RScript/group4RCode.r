library(XML)
library(rvest)
library(stringr)
library(RSelenium)

zpids=c()
href=c()
YearBuilt=c()
LotSize=c()
FloorSize=c()
CurrentPrice=c()
PriceSqft=c()
MLSNumber=c()
address=c()
ParcelNumber=c()
stories=c()
ZillowHomeID=c()
LastRemodelYear=c()
StructureType=c()
RoomNumber=c()
ZipCode=c()
HouseType=c()
BedNumber=c()
BathNumber=c()
skls=c()
pHist=c()
tHist=c()
neighbourHood=c()

#yearBuilt
Year_Built=function(facts)
{
  yb<-grep("Built in",facts)
  if(!length(yb)==0)
  {YearBuilt=c(YearBuilt,sub("(.*) ","",facts[yb]))
  }else
  {YearBuilt=c(YearBuilt,"NA")}
  return(YearBuilt)
}
##LotSize
Lot_Size=function(facts)
{
  ls<-grep("Lot",facts)
  if(!length(ls)==0)
  {LotSize=c(LotSize,sub("(.*): ","",facts[ls]))
  }else
  {LotSize=c(LotSize,"NA")}
  return(LotSize)
}
##Price/sqft
Price_Sqft=function(facts)
{
  pps<-grep("Price/sqft",facts)
  if(!length(pps)==0)
  {PriceSqft=c(PriceSqft,sub("(.*): ","",facts[pps]))
  }else
  {PriceSqft=c(PriceSqft,"NA")}
  return(PriceSqft)
}
##MLS
MLS_Number=function(facts)
{mls<-grep("MLS #",facts)
if(!length(mls)==0)
{MLSNumber=c(MLSNumber,sub("(.*): ","",facts[mls]))
}else
{MLSNumber=c(MLSNumber,"NA")}
return(MLSNumber)}
##Neighbour
Neighborhood=function(neighbour)
{nbr<-grep("Neighborhood:",neighbour)
if(!length(nbr)==0)
{neighbourHood=c(neighbourHood,sub("(.*): ","",neighbour[nbr]))
}else
{neighbourHood=c(neighbourHood,"NA")}
return(neighbourHood)}
#Address
Address=function(meta)
{
  
  if(!length(meta)==0){
    ans<-html_attr(meta,"content")
    address=c(address,ans)
  }else
  {address=c(address,"NA")
  return(address)}
}
#FloorSize
Floor_Size=function(others)
{
  fs<-grep("Floor size",others)
  if(!length(fs)==0)
  {FloorSize=c(FloorSize,sub("(.*): ","",others[fs]))
  }else
  {FloorSize=c(FloorSize,"NA")}
  return(FloorSize)}
#ParcelNumber
Parcel_Number=function(others)
{
  pn<-grep("Parcel",others)
  if(!length(pn)==0)
  {ParcelNumber=c(ParcelNumber,sub("(.*): ","",others[pn]))
  }else
  {ParcelNumber=c(ParcelNumber,"NA")}
  return(ParcelNumber)}
#Stories
Stories=function(others)
{
  s<-grep("^Stories",others)
  if(!length(s)==0)
  {stories=c(stories,sub("(.*): ","",others[s]))
  }else
  {stories=c(stories,"NA")}
  return(stories)}
#ZillowHomeId
Zillow_Home_ID=function(others)
{
  zid<-grep("Zillow Home ID",others)
  if(!length(zid)==0)
  {ZillowHomeID=c(ZillowHomeID,sub("(.*): ","",others[zid]))
  }else
  {ZillowHomeID=c(ZillowHomeID,"NA")}
  return(ZillowHomeID)}
#LastRemodelYear
Last_Remodel_Year=function(others)
{
  lry<-grep("Last remodel",others)
  if(!length(lry)==0)
  {LastRemodelYear=c(LastRemodelYear,sub("(.*): ","",others[lry]))
  }else
  {LastRemodelYear=c(LastRemodelYear,"NA")}
  return(LastRemodelYear)}
#StructureType
Structure_Type=function(others)
{
  st<-grep("Structure type",others)
  if(!length(st)==0)
  {StructureType=c(StructureType,sub("(.*): ","",others[st]))
  }else
  {StructureType=c(StructureType,"NA")}
  return(StructureType)}
#RoomNumber
Room_Number=function(others)
{
  rn<-grep("Room count",others)
  if(!length(rn)==0)
  {RoomNumber=c(RoomNumber,sub("(.*): ","",others[rn]))
  }else
  {RoomNumber=c(RoomNumber,"NA")}
  return(RoomNumber)}
#ZipCode
Zip_Code=function(meta)
{
  if(!length(meta)==0){
    zipAdd<-html_attr(meta,"content")
    zc=grep("(.*) [0-9]{5}$",zipAdd)
    if(zc==1){
      ZipCode=c(ZipCode,sub("(.*) ","",zipAdd))
    }else{
      ZipCode=c(ZipCode,"NA")
    }
  }else{
    ZipCode=c(ZipCode,"NA")
  }
  
    return(ZipCode)
}
#HouseType
House_Type=function(facts)
{
  ht=facts[grep("([Ss]ingle [Ff]amily)|([Mm]ulti [Ff]amily)|([Cc]ondo) ",facts)]
  if(!length(ht)==0)
  {HouseType=c(HouseType,ht)
  }else
  {HouseType=c(HouseType,"NA")}
  return(HouseType)
}
#BedNumber
Bed_Number=function(heads)
{
  bn=heads[grep("(.*) bed",heads)]
  if(!length(bn)==0)
  {BedNumber=c(BedNumber,sub(" (.*)","",bn))
  }else
  {BedNumber=c(BedNumber,"NA")}
  return(BedNumber)
}
#BathNumber
Bath_Number=function(heads)
{
  btn=heads[grep("(.*) bath",heads)]
  if(!length(btn)==0)
  {BathNumber=c(BathNumber,sub(" (.*)","",btn))
  }else
  {BathNumber=c(BathNumber,"NA")}
  return(BathNumber)
}
#Schools
SchoolNames=function(schools)
{
  if(!length(schools)==0)
  { skools=""
  lk=str_replace_all(schools,"\n","")
  pk=str_replace_all(lk," \\s+","_")
  dk=str_replace_all(pk,"(^_)|(_$)","")
  for(a in 1:length(schools))
  {
    skools=paste(skools,dk[a],sep=";") 
  }
  
  skls=c(skls,skools)
  }else
  {skls=c(skls,"NA")}
  return(str_replace_all(skls,"^;",""))
}
historyTables<-function(tableType,tableNode,priceNode)
{
  
  if(length(tableNode)==0){
    print("came here")
    return("NA")
  }else{
    remDr$setImplicitWaitTimeout(20000)
    tab <-remDr$findElements(using = 'class','zsg-table')
    if(length(tab)==0){
      return("NA")
    }
    if(tableType=="price"){
      a<-tab[[1]]$getElementAttribute("outerHTML")
    }else{
      if(length(tab)<2){
        a<-tab[[1]]$getElementAttribute("outerHTML")
      }else{
        a<-tab[[2]]$getElementAttribute("outerHTML")  
      }
      
    }
    
    table1 <- readHTMLTable(a[[1]], header=TRUE, as.data.frame=TRUE)[[1]]
    acc<-table1
    ta<-table1[-length(table1)]
    
    ans<-""
    for(i in 1:nrow(ta)){
      for(j in 1:ncol(ta)){
        
        if(j==1){
          ans<-paste0(ans,toString(ta[i,j]))
        }else{
          ans<-paste(ans,toString(ta[i,j]),sep = "_")
          
        }
      }
      ans<-paste0(ans,";")
    }
    return(ans)
  }
}
CurrentPrice<-function(CurrentPriceNode)
{
  if(length(CurrentPriceNode)==0){
    return("NA")
  }else{
    return(html_text(CurrentPriceNode))  
  }
}


#AssigningbaseURl
url = "https://www.zillow.com/homes/for_sale/Chicago-IL/17426_rid/2399001-_price/9063-_mp/globalrelevanceex_sort/42.121145,-87.263032,41.546102,-88.200989_rect/9_zm/0_mmm/"
pages=c()

#Fetching the Zillow PIDs and saving HTML files
for (i in 1:19)
{
  k=readLines(paste0(url,i,"_p"))
  htmlpage <- htmlParse(k, asText = TRUE)
  #zpid <- c(zpid,xpathSApply(htmlpage, "//*[@id='search-results']/ul[@class='photo-cards']/li/article", function(u) xmlAttrs(u)["data-zpid"]))
  href <- c(href,xpathSApply(htmlpage, "//*[@id='search-results']/ul[@class='photo-cards']/li/article/div[@class='zsg-photo-card-content zsg-aspect-ratio-content']/a", function(u) xmlAttrs(u)["href"]))
  
  pages=c(pages,htmlpage)
}


# Selenium Server creation
rD <- rsDriver() # Search and download selenium java binary. This code need to be executed only once for checking connection establishment with selenium server
remDr <- rD$client

  #URLs for each house
  url="https://www.zillow.com"
  individualUrl=paste0(url,href)
  individualUrl=individualUrl[1:length(individualUrl)]
  
  for(j in 1:length(individualUrl))
  { 
    indPage = read_html(individualUrl[j])
    priceNode=html_node(indPage,xpath='//div[@id="hdp-price-history"]')
    taxNode=html_node(indPage,xpath='//div[@id="hdp-tax-history"]')
    
    remDr$navigate(individualUrl[j])  #remDR is with Rselenium package
    
    
    factNodes=html_nodes(indPage,xpath="//*[@id='hdp-content']/div[@role='main']/section[@class='zsg-content-section ']/div[@class='hdp-facts zsg-content-component z-moreless']/div[@class='fact-group-container zsg-content-component top-facts']/ul[@class='zsg-list_square zsg-lg-1-3 zsg-md-1-2 zsg-sm-1-1']/li")
    facts = html_text(factNodes)
    
       
    meta=html_node(indPage,xpath = '//head/meta[@property="og:zillow_fb:address"]')
    
    
    otherNodes=html_nodes(indPage,xpath="//*[@id='hdp-content']/div[@role='main']/section[@class='zsg-content-section ']/div[@class='hdp-facts zsg-content-component z-moreless']/div[@class='fact-group-container zsg-content-component z-moreless-content hide']/ul[@class='zsg-list_square zsg-lg-1-3 zsg-md-1-2 zsg-sm-1-1']/li")
    others = html_text(otherNodes)
    
    headNodes=html_nodes(indPage,xpath="//*[@id='hdp-content']/div[@role='main']/div[@class='zsg-lg-2-3 zsg-sm-1-1 hdp-header-description']/header[@class='zsg-content-header addr']/h3/span")
    heads = html_text(headNodes)
    
    schoolNodes=html_nodes(indPage,xpath="//*[@id='nearbySchools']/div[1]/div[@class='zsg-content-item']/ul[@class='nearby-schools-list']/li[@class='nearby-school assigned-school  clearfix']/div[@class='nearby-schools-info']")
    schools = html_text(schoolNodes)
    
    neighbourNodes=html_nodes(indPage,xpath="//*[@id='hdp-content']/div[@role='main']/section[@id='hdp-neighborhood']/h2")
    neighbour = html_text(neighbourNodes)
    
    CurrentPriceNode=html_node(indPage,xpath='//*[@id="home-value-wrapper"]/div[@class="estimates"]/div[@class="main-row  home-summary-row"]/span[1]')
    CurrentPrice=c(CurrentPrice,CurrentPrice(CurrentPriceNode))
    
    priceNode=html_node(indPage,xpath='//div[@id="hdp-price-history"]')
    
    YearBuilt=Year_Built(facts)
    LotSize=Lot_Size(facts)
    PriceSqft=Price_Sqft(facts)
    FloorSize=Floor_Size(others)
    MLSNumber=MLS_Number(facts)
    address=Address(meta)
    ParcelNumber=Parcel_Number(others)
    stories=Stories(others)
    ZillowHomeID=Zillow_Home_ID(others)
    LastRemodelYear=Last_Remodel_Year(others)
    neighbourHood=Neighborhood(neighbour)
    StructureType=Structure_Type(others)
    RoomNumber=Room_Number(others)
    ZipCode=Zip_Code(meta)
    HouseType=House_Type(facts)
    BedNumber=Bed_Number(heads)
    BathNumber=Bath_Number(heads)
    skls=SchoolNames(schools)
    
    
    
    #print(length(priceNode))
    #print(length(taxNode))
    
    pHist = c(pHist,historyTables("price",priceNode,priceNode))
    tHist = c(tHist,historyTables("tax",taxNode,priceNode))
    
    write_html(indPage,file =sprintf("C:\\Users\\Subrahmanyam\\Desktop\\Kavita Project\\Zillow\\html\\%s.html",ZillowHomeID[length(ZillowHomeID)]))
    
    
  }
  
  
DF=data.frame("Zillow_Home_ID"=ZillowHomeID,"Current_Price"=CurrentPrice,"Price_Each_SQFT"=PriceSqft,"Price_History"=pHist,"Tax_History"=tHist,"URL"=individualUrl,"Address"=address,"Zip_Code"=ZipCode,"NEIGHBOURHOOD"=neighbourHood,"School"=skls,"Lot_Size"=LotSize,"Floor_Size"=FloorSize,"MLS_Number"=MLSNumber,"Parcel_Number"=ParcelNumber,"stories"=stories,"Built_Year"=YearBuilt,"Last_Year_Remodel"=LastRemodelYear,"House_Type"=HouseType,"Structure_Type"=StructureType,"Bath_Number"=BathNumber,"Bed_Number"=BedNumber,"Room_Num"=RoomNumber)
write.csv(DF,"C:\\Users\\Subrahmanyam\\Desktop\\Kavita Project\\Zillow\\csv\\test.csv")
