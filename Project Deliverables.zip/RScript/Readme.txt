Fucntion Name : Year_Built
Description : This function scrapes the year the house was built. It uses the xpath to locate the year the house was built. 
Since we are using the xpath for the facts under which the year built is found.

Function Name : Lot_Size

Description : This function scrapes the lot size of the house. We query it from the facts which are scraped using the xpath of Facts. 
Since we are using the xpath for the facts under which the year built is found.

Function Name : Price_Sqft

Description : This function scrapes the price per SQFT of the house. It finds the price per sqft from the fact that is fetched using xpath of fact. 
Since we are using the xpath for the facts under which the year built is found.

Function Name : MLS_Number

Description : This function scrapes the MLS number of the house. It finds the MLS number of the house from the fact that is fetched using xpath of fact. 
Since we are using the xpath for the facts under which the year built is found.

Function Name: Neighborhood

Description : This function scrapes the Neighbourhood data of the house. It scapes the neighbourhood data from the neighbour which then gets the data from the
individual HTML page that we crawl

Function name :  Address

Description : This function fetches the house address from the Meta field that we have scraped using the XPath of the HTML files that we crawl.

Function Name : Floor_Size

Description : This function fetches the floor size of the house that is there, We fetch by using the data collected in "Meta" field. This data is scraped from the
HTML pages that we crawl for each house.

Function Name :  Parcel_Number

Description : This function fetches the parcel number of the house that is there, We fetch by using the data collected in "Others" field. This data is scraped from the
HTML pages that we crawl for each house.

Function Name : Stories

Description : This function fetches the stories of the house that is there, We fetch by using the data collected in "Others" field. This data is scraped from the
HTML pages that we crawl for each house.

Function Name : Zillow_Home_ID

Description : The Zillow Home ID is present in the others field as well as the href that we gather of the individual house from the homepage of the url, we are using the
grep from the other facts that are present in the individual house URL

Function Name : Last_Remodel_Year

Description : This function fetches the last remodel year of the house that is there, We fetch by using the data collected in "Others" field. This data is scraped from the
HTML pages that we crawl for each house.

Function Name : Structure_Type

Description : This function fetches the structure type of the house that is there, We fetch by using the data collected in "Others" field. This data is scraped from the
HTML pages that we crawl for each house.

Function Name : Room_Number

Description : This function fetches the number of rooms present in the house that is there, We fetch by using the data collected in "Others" field. This data is scraped from the
HTML pages that we crawl for each house.

Function Name : Zipcode

Description : This function fetches the Zipcode of the house that is there, We fetch by using the data collected in "Meta" field. This data is scraped from the
HTML pages that we crawl for each house.

Function Name : House_Type

Description : This function fetches the type of the house that is there, We fetch by using the data collected in "Facts" field. This data is scraped from the
HTML pages that we crawl for each house.

Function Name: Bed_Number

Description : This function fetches the number of beds in the house that is there, We fetch by using the data collected in "Head" field. This field displays the top information that 
is present for each house. This data is scraped from the HTML pages that we crawl for each house.

Functiona Name : SchoolNames

We fetch the school names by parsing the data that we have gathered in the schools variable which we can fetch directly from the xpath

Function Name : historyTables

This function uses the selenium call because the Price History and Tax History data is generated dynamically. For this reason we require to crawl through 
each page by opening that in the browser.

Function Name : CurrentPrice

This function fetched the current price of the house that we have scraped from the page using xpath of the field current price.



