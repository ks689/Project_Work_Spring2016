import java.util.Arrays;

public class SparseMatrix {

	private MatrixEntry[] array;
	// private int numEntries;
	public String[] tempString;
	public int numEntries, strRow, strCol;

	public int q;
	private int m;
	private int n;

	public SparseMatrix(int m, int n) {
		this.m = m;
		this.n = n;

		// You will need to "grow" the array efficiently
		// as more values are added.
//if(this.array != null)
		this.array = new MatrixEntry[m * n];

	}

	public int getM() {
		return m;
	}

	public void setM(int m) {
		this.m = m;
	}

	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
	}

	public SparseMatrix(String str) {
		m = 0;
		n = 0;

		tempString = str.split(",");
		this.array = new MatrixEntry[tempString.length];
		for (int i = 0; i <= tempString.length - 1; i++) {
			// System.out.println(tempString[i]);
			numEntries = Integer.parseInt(tempString[i].substring(0, tempString[i].indexOf("r")));
			strRow = Integer
					.parseInt(tempString[i].substring(tempString[i].indexOf("r") + 1, tempString[i].indexOf("c")));
			strCol = Integer.parseInt(tempString[i].substring(tempString[i].indexOf("c") + 1, tempString[i].length()));
			// System.out.println(strCol);
			if (strRow > m) {
				m = strRow;

			}

			if (strCol > n) {
				n = strCol;

			}

			array[i] = new MatrixEntry(numEntries, strRow, strCol);
			// System.out.println("Row Number for index"+ i + "
			// "+array[i].getRow());
		}

		// System.out.println("Number of Rows is" + " "+ m);
		// System.out.println("Number of Columns is" + " "+ n);

		array = sortArray(array);

	}

	public MatrixEntry[] sortArray(MatrixEntry[] unSortArr) {

		for (int i = 0; i < unSortArr.length - 1; i++) {

			for (int j = 0; j < unSortArr.length - i - 1; j++) {

				if (unSortArr[j].conCat(unSortArr[j].getRow(), unSortArr[j].getCol()) > unSortArr[j + 1]
						.conCat(unSortArr[j + 1].getRow(), unSortArr[j + 1].getCol())) {

					MatrixEntry temp = unSortArr[j];

					unSortArr[j] = unSortArr[j + 1];

					unSortArr[j + 1] = temp;

				}
			}
		}

		return unSortArr;
	}

	public SparseMatrix(int cRow, int cColumn, String matrixValue) {
		m = 1;
		n = 1;
		// int c = 0, d = 0, e = 0, f = 0, g = 0;
		int c = 0;
		this.array = new MatrixEntry[10];

		switch (matrixValue) {
		case "C": {

			for (int i = 1; i <= cRow; i++) {
				for (int j = 1; j <= cColumn; j++) {

					if ((i + j) % 2 == 0) {
						numEntries = i * j;
						if (c < array.length) {

							array[c] = new MatrixEntry(numEntries, i, j);
							c++;
						} else {
							array = Arrays.copyOf(array, array.length + 1);
							array[c] = new MatrixEntry(numEntries, i, j);
							c++;

						}
					}

				}

			}

		}
			break;
		case "D": {
			for (int i = 1; i <= cRow; i++) {
				for (int j = 1; j <= cColumn; j++) {

					if ((i * j) % 4 == 0) {
						numEntries = i + j;
						if (c < array.length) {

							array[c] = new MatrixEntry(numEntries, i, j);
							c++;
						} else {
							array = Arrays.copyOf(array, array.length + 1);
							array[c] = new MatrixEntry(numEntries, i, j);
							c++;

						}
					}
				}

			}

		}
			break;
		case "E": {

			for (int i = 1; i <= cRow; i++) {
				for (int j = 1; j <= cColumn; j++) {

					if (i % 10 == 0) {
						numEntries = i + (2 * j);
						if (c < array.length) {

							array[c] = new MatrixEntry(numEntries, i, j);
							c++;
						} else {
							array = Arrays.copyOf(array, array.length + 1);
							array[c] = new MatrixEntry(numEntries, i, j);
							c++;

						}
					}
				}

			}
		}

			break;
		case "F": {

			for (int i = 1; i <= cRow; i++) {
				for (int j = 1; j <= cColumn; j++) {

					if (i % 5 == 0) {
						numEntries = 5 * i;
						if (c < array.length) {

							array[c] = new MatrixEntry(numEntries, i, j);
							c++;
						} else {
							array = Arrays.copyOf(array, array.length + 1);
							array[c] = new MatrixEntry(numEntries, i, j);
							c++;

						}
					}

				}

			}

		}
			break;
		case "G": {
			for (int i = 1; i <= cRow; i++) {
				for (int j = 1; j <= cColumn; j++) {

					if (i % j == 0) {
						numEntries = i + j;
						if (c < array.length) {

							array[c] = new MatrixEntry(numEntries, i, j);
							c++;
						} else {
							array = Arrays.copyOf(array, array.length * 2);
							array[c] = new MatrixEntry(numEntries, i, j);
							c++;

						}
					}

				}

			}

		}

		}

		m = cRow;
		n = cColumn;

	}

	public void print() {

		q = 0;
		int ans = 0;
		for (int i = 1; i <= m; i++) {
			for (int j = 1; j <= n; j++) {
				if (i == array[q].getRow() && j == array[q].getCol()) {
					ans = array[q].getValue();
					if (q < array.length - 1) {
						q++;

					}

				} else {
					ans = 0;

				}
				if (m <= 6 && n <= 6) {
					System.out.print(ans + "   ");
				}

				if (m > 6 && n <= 6) {
					if (i <= 2 || i >= m - 1) {
						System.out.print(ans + "   ");
					} else if (i == 3) {
						System.out.print(".");
					} 

				}
				if (m <= 6 && n > 6) {
					if (j <= 2 || j >= n - 1) {
						System.out.print(ans + "   ");
					} else if (j == 3) {
						System.out.print(".");
					} 
				}
				if (m > 6 && n > 6) {
					if ((i <= 2 || i >= m - 1) && (j <= 2 || j >= n - 1)) {
						System.out.print(ans + "   ");
					} else if ((i == 3 && j <= 5) || (j == 3 && i <= 5)) {
						System.out.print(".");
					} 
				}
			}
			if ((m > 6 && (i <= 3 || i >= m - 1))) {
				System.out.println();
			} else if (m <= 6) {
				System.out.println();
			}

		}
	}

	public MatrixEntry[] scalarMultiply(int c) {
		MatrixEntry[] tempArray = new MatrixEntry[this.array.length];
		System.arraycopy(this.array, 0, tempArray, 0, this.array.length);
		for (int i = 0; i < this.array.length; i++) {
			if(array[i] == null)
				break;
              tempArray[i] = new MatrixEntry(this.array[i].getValue(), this.array[i].getRow(), this.array[i].getCol());
			  tempArray[i].setValue(this.array[i].getValue() * c);

		}
		return tempArray;
	}

	public MatrixEntry[] getArray() {
		return array;
	}

	public void setArray(MatrixEntry[] array) {
		this.array = array;
	}

	public boolean equals(SparseMatrix mat) {
		if (this.getM() == mat.getM() && this.getN() == mat.getN() && this.array.length == mat.array.length) {
			for (int i = 0; i < array.length; i++) {
				if(array[i]==null)
					break;
				if (!(this.array[i].getRow() == mat.array[i].getRow() && this.array[i].getCol() == mat.array[i].getCol()
						&& this.array[i].getValue() == mat.array[i].getValue())) {
					return false;
				}
			}
			return true;
		} else {
			return false;
		}

	}
	
	public MatrixEntry[] add(SparseMatrix mat) {
		
		
		MatrixEntry[] tempArray = new MatrixEntry[array.length];
		System.arraycopy(this.array, 0, tempArray, 0, this.array.length);
		for (int i = 0; i < array.length; i++) {
			if(array[i] == null)
				break;
			tempArray[i] = new MatrixEntry(this.array[i].getValue(), this.array[i].getRow(), this.array[i].getCol());
			
				tempArray[i].setValue(this.array[i].getValue() + mat.array[i].getValue());
										
		}
		return tempArray;
			
		
	}
	

	public MatrixEntry[] subtract(SparseMatrix mat) {
		MatrixEntry[] tempArray = new MatrixEntry[array.length];
		// if(this.getM()==mat.getM() && this.getN()==mat.getN() &&
		// this.array.length==mat.array.length){

		for (int i = 0; i < array.length; i++) {
			if(array[i] == null)
				break;
			tempArray[i] = new MatrixEntry(this.array[i].getValue(), this.array[i].getRow(), this.array[i].getCol());
				tempArray[i].setValue(tempArray[i].getValue() - mat.array[i].getValue());
				// }
			}
		
		return tempArray;
	}

	
//	  public MatrixEntry[] multiply(SparseMatrix mat) { 
//		  MatrixEntry[] tempArray = new MatrixEntry[array.length];
//		 int k =0;
//		  if (this.getM() == mat.getN()) {
//				for (int i = 0; i < array.length; i++) {
//					for(int j=k; j<k+this.getM(); j++){
//						if(this.array[i].getValue()!=0 && mat.array[i].getValue()!=0){
//						tempArray[i].setValue( tempArray[i].getValue() + array[j].getValue() * mat.array[j].getValue());
//						}
//						k++;
//					
//					}
//					
//					}
//				
//				}
//		  return tempArray;
//	  }
	  
	  public SparseMatrix multiply(SparseMatrix mat) { 
		  SparseMatrix sparseMat = new SparseMatrix(this.getM() , mat.n);
		  if(this.getN() == mat.m)
	    	{
	    		int l=0 , sum = 0;
	    		for(int i = 1; i <= this.getM() ; i++)
	    		{
	    			for(int j = 1; j <= mat.getN() ; j++)
	    			{
	    				for(int k = 1 ; k <= this.getN(); k++)
	    				{
	    					sum += (checkElementExists(i, k, this.array)*checkElementExists(k,j,mat.array));
	    				}
	    				sparseMat.array[l] = new MatrixEntry(sum, i , j);
	    				sum = 0;
	    				l++;		
	    				if(l == (sparseMat.array.length - 1))
				    	{
							MatrixEntry[] tempArray = new MatrixEntry[2*sparseMat.array.length];
				    		System.arraycopy(sparseMat.array, 0, tempArray, 0, sparseMat.array.length);
				    		sparseMat.array = new MatrixEntry[tempArray.length]; 
				    		System.arraycopy(tempArray, 0, sparseMat.array, 0, tempArray.length);
							//array = Arrays.copyOf(array, 2*array.length);    		
				    	}    
	    			}
	    		}
	    		return sparseMat;
	    	}
	    	else
	    	{
	    		System.out.println("Matrices Cannot be multiplied");
	    	}
	    	return sparseMat;
 
	  }
	  
	  public int checkElementExists(int row,int column,MatrixEntry[] arr){
		  for(int i=0;i<arr.length;i++){
			  if(arr[i].getCol()==column && arr[i].getRow()==row){
				  return returnValue(row, column, arr);
			  }
		  }
		  return 0;
	  }
	  
	  public int returnValue(int row,int column,MatrixEntry[] arr){
		  for(int i=0;i<arr.length;i++){
			  if(arr[i].getCol()==column && arr[i].getRow()==row){
				  return arr[i].getValue();
			  }
		  }
		  return 0;
	  }
	  
	  public MatrixEntry[] power(int p) {
		  
			SparseMatrix newMat = new SparseMatrix(this.getM(), this.getN());
			newMat= this.multiply(this);
			for (int i = 2; i < p; i++) {
	          newMat = newMat.multiply(this);        	    
			}
			return newMat.getArray();
	  }
	  
	  public MatrixEntry[] transpose() {
		  MatrixEntry[] tempArray = new MatrixEntry[array.length];
			//System.arraycopy(this.array, 0, tempArray, 0, this.array.length);
			for (int i = 0; i < array.length; i++) {
				
				tempArray[i] = new MatrixEntry(this.array[i].getValue(), this.array[i].getCol(), this.array[i].getRow());

			}
			tempArray = sortArray(tempArray);
			return tempArray;
	  }
	  
}

