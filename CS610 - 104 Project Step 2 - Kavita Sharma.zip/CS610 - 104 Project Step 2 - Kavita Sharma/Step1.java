
public class Step1 {

	public static void main(String[] args){
		final long totalTime = System.nanoTime();
	
/*STEP 1*/		
/*Initialize matrices A � G.*/
		String matStrA = "-5r4c4,5r1c4,2r2c2,5r3c1,-3r3c2,6r4c2,-7r2c3,3r1c1";
		String matStrB = "1r4c4,1r3c3,1r2c6,1r4c1,1r2c2,1r1c5,1r1c1";
			
		SparseMatrix matA= new SparseMatrix(matStrA);
		SparseMatrix matB= new SparseMatrix(matStrB);
	    SparseMatrix matC= new SparseMatrix(5, 6, "C");
		SparseMatrix matD= new SparseMatrix(6, 5, "D");
		SparseMatrix matE=new SparseMatrix(200, 200, "E");
		SparseMatrix matF=new SparseMatrix(200, 1, "F");
	    SparseMatrix matG=new SparseMatrix(30000, 30000, "G");

/*Print matrices A � G using print().*/	    
		System.out.println("Matrix A is :");
		matA.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Matrix B is : ");
		matB.print();
		System.out.println();
		System.out.println();
				
		System.out.println("Matrix C is : ");
		matC.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Matrix D is : ");
		matD.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Matrix E is : ");
		matE.print();
		System.out.println();
		System.out.println();		
		
		System.out.println("Matrix F is : ");
		matF.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Matrix G is : ");
		matG.print();
		System.out.println();
		System.out.println();
	
/*Scalar multiply each matrix by 5 and print the result*/		
		System.out.println("Scalar Multiply of A ");
		SparseMatrix a = new SparseMatrix(4, 4);
		a.setArray(matA.scalarMultiply(5));
		a.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Scalar Multiply of B ");
		SparseMatrix b = new SparseMatrix(4, 6);
		b.setArray(matB.scalarMultiply(5));
		b.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Scalar Multiply of C ");
		SparseMatrix c = new SparseMatrix(5, 6);
		c.setArray(matC.scalarMultiply(5));
		c.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Scalar Multiply of D");
		SparseMatrix d = new SparseMatrix(6, 5);
		d.setArray(matD.scalarMultiply(5));
		d.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Scalar Multiply of E");
		SparseMatrix e = new SparseMatrix(200, 200);
		e.setArray(matE.scalarMultiply(5));
		e.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Scalar Multiply of F");
		SparseMatrix f = new SparseMatrix(200, 1);
		f.setArray(matF.scalarMultiply(5));
		f.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Scalar Multiply of G");
		SparseMatrix g = new SparseMatrix(30000, 30000);
		g.setArray(matG.scalarMultiply(5));
		g.print();
		System.out.println();
		System.out.println();
		
	
/*Apply equals() pairwise among matrices A � G (i.e., compare A to A, A to B, A to C, etc.).*/		
		System.out.println("Matrix A is equal to Matrix A" + " : " +matA.equals(matA));
		System.out.println("Matrix A is equal to Matrix B" + " : " +matA.equals(matB));
		System.out.println("Matrix A is equal to Matrix C" + " : " +matA.equals(matC));
		System.out.println("Matrix A is equal to Matrix D" + " : " +matA.equals(matD));
		System.out.println("Matrix A is equal to Matrix E" + " : " +matA.equals(matE));
		System.out.println("Matrix A is equal to Matrix F" + " : " +matA.equals(matF));
		System.out.println("Matrix A is equal to Matrix G" + " : " +matA.equals(matG));
		
		System.out.println();
		System.out.println("Matrix B is equal to Matrix A" + " : " +matB.equals(matA));
		System.out.println("Matrix B is equal to Matrix B" + " : " +matB.equals(matB));
		System.out.println("Matrix B is equal to Matrix C" + " : " +matB.equals(matC));
		System.out.println("Matrix B is equal to Matrix D" + " : " +matB.equals(matD));
		System.out.println("Matrix B is equal to Matrix E" + " : " +matB.equals(matE));
		System.out.println("Matrix B is equal to Matrix F" + " : " +matB.equals(matF));
		System.out.println("Matrix B is equal to Matrix G" + " : " +matB.equals(matG));
		
		System.out.println();
		System.out.println("Matrix C is equal to Matrix A" + " : " +matC.equals(matA));
		System.out.println("Matrix C is equal to Matrix B" + " : " +matC.equals(matB));
		System.out.println("Matrix C is equal to Matrix C" + " : " +matC.equals(matC));
		System.out.println("Matrix C is equal to Matrix D" + " : " +matC.equals(matD));
		System.out.println("Matrix C is equal to Matrix E" + " : " +matC.equals(matE));
		System.out.println("Matrix C is equal to Matrix F" + " : " +matC.equals(matF));
		System.out.println("Matrix C is equal to Matrix G" + " : " +matC.equals(matG));
		
		System.out.println();
		System.out.println("Matrix D is equal to Matrix A" + " : " +matD.equals(matA));
		System.out.println("Matrix D is equal to Matrix B" + " : " +matD.equals(matB));
		System.out.println("Matrix D is equal to Matrix C" + " : " +matD.equals(matC));
		System.out.println("Matrix D is equal to Matrix D" + " : " +matD.equals(matD));
		System.out.println("Matrix D is equal to Matrix E" + " : " +matD.equals(matE));
		System.out.println("Matrix D is equal to Matrix F" + " : " +matD.equals(matF));
		System.out.println("Matrix D is equal to Matrix G" + " : " +matD.equals(matG));
		
		System.out.println();
		System.out.println("Matrix E is equal to Matrix A" + " : " +matE.equals(matA));
		System.out.println("Matrix E is equal to Matrix B" + " : " +matE.equals(matB));
		System.out.println("Matrix E is equal to Matrix C" + " : " +matE.equals(matC));
		System.out.println("Matrix E is equal to Matrix D" + " : " +matE.equals(matD));
		System.out.println("Matrix E is equal to Matrix E" + " : " +matE.equals(matE));
		System.out.println("Matrix E is equal to Matrix F" + " : " +matE.equals(matF));
		System.out.println("Matrix E is equal to Matrix G" + " : " +matE.equals(matG));
		
		System.out.println();
		System.out.println("Matrix F is equal to Matrix A" + " : " +matF.equals(matA));
		System.out.println("Matrix F is equal to Matrix B" + " : " +matF.equals(matB));
		System.out.println("Matrix F is equal to Matrix C" + " : " +matF.equals(matC));
		System.out.println("Matrix F is equal to Matrix D" + " : " +matF.equals(matD));
		System.out.println("Matrix F is equal to Matrix E" + " : " +matF.equals(matE));
		System.out.println("Matrix F is equal to Matrix F" + " : " +matF.equals(matF));
		System.out.println("Matrix F is equal to Matrix G" + " : " +matF.equals(matG));
		
		System.out.println();
		System.out.println("Matrix G is equal to Matrix A" + " : " +matG.equals(matA));
		System.out.println("Matrix G is equal to Matrix B" + " : " +matG.equals(matB));
		System.out.println("Matrix G is equal to Matrix C" + " : " +matG.equals(matC));
		System.out.println("Matrix G is equal to Matrix D" + " : " +matG.equals(matD));
		System.out.println("Matrix G is equal to Matrix E" + " : " +matG.equals(matE));
		System.out.println("Matrix G is equal to Matrix F" + " : " +matG.equals(matF));
		System.out.println("Matrix G is equal to Matrix G" + " : " +matG.equals(matG));

/*STEP 2*/
		
/*Add each matrix to itself and print the result*/
		final long addTime = System.nanoTime();
		
		System.out.println();
		System.out.println("Add A ");
		a.setArray(matA.add(matA));
		a.print();
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println("Add B ");
		b.setArray(matB.add(matB));
		b.print();
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println("Add C ");
		c.setArray(matC.add(matC));
		c.print();
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println("Add D ");
		d.setArray(matD.add(matD));
		d.print();
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println("Add E ");
		e.setArray(matE.add(matE));
		e.print();
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println("Add F ");
		f.setArray(matF.add(matF));
		f.print();
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println("Add G ");
		g.setArray(matG.add(matG));
		g.print();
		System.out.println();
		System.out.println();
		final long addDuration = System.nanoTime() - addTime;
				
/*Subtract each matrix from itself and print the result*/
		final long subTime = System.nanoTime();
		System.out.println();
		System.out.println("Subtract A ");
		a.setArray(matA.subtract(matA));
		a.print();
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println("Subtract B ");
		b.setArray(matB.subtract(matB));
		b.print();
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println("Subtract C ");
		c.setArray(matC.subtract(matC));
		c.print();
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println("Subtract D ");
		d.setArray(matD.subtract(matD));
		d.print();
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println("Subtract E ");
		e.setArray(matE.subtract(matE));
		e.print();
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println("Subtract F ");
		f.setArray(matF.subtract(matF));
		f.print();
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println("Subtract G ");
		g.setArray(matG.subtract(matG));
		g.print();
		System.out.println();
		System.out.println();
		
		final long subDuration = System.nanoTime() - subTime;
		
/*Scalar multiply each matrix by five and then subtract the matrix (e.g., 5A � A)
 * and print the result*/
		final long scalarSubTime = System.nanoTime();
		System.out.println("5A minus A ");
		a.setArray(matA.scalarMultiply(5));
		a.setArray(a.subtract(matA));
		a.print();
		System.out.println();
		System.out.println();
		
		System.out.println("5B minus B ");
		b.setArray(matB.scalarMultiply(5));
		b.setArray(b.subtract(matB));
		b.print();
		System.out.println();
		System.out.println();
		
		System.out.println("5C minus C ");
		c.setArray(matC.scalarMultiply(5));
		c.setArray(c.subtract(matC));
		c.print();
		System.out.println();
		System.out.println();
		
		System.out.println("5D minus D ");
		d.setArray(matD.scalarMultiply(5));
		d.setArray(d.subtract(matD));
		d.print();
		System.out.println();
		System.out.println();
		
		System.out.println("5E minus E ");
		e.setArray(matE.scalarMultiply(5));
		e.setArray(e.subtract(matE));
		e.print();
		System.out.println();
		System.out.println();
		
		System.out.println("5F minus F ");
		f.setArray(matF.scalarMultiply(5));
		f.setArray(f.subtract(matF));
		f.print();
		System.out.println();
		System.out.println();
		
		System.out.println("5G minus G ");
		g.setArray(matG.scalarMultiply(5));
		g.setArray(g.subtract(matG));
		g.print();
		System.out.println();
		System.out.println();
		final long scalarSubDuration = System.nanoTime() - scalarSubTime;	
		
/*Multiply Matrix B with the transpose of Matrix C, Matrix C with Matrix D, Matrix D with Matrix C, and
Matrix E with Matrix F. Print the result for each.*/
	
/*Matrix B with the transpose of Matrix C*/
		final long multiplicationTime = System.nanoTime();
		System.out.println("Multiplication of B with transpose of C ");
		SparseMatrix btc = new SparseMatrix(4,5);
		SparseMatrix cMat = new SparseMatrix(6, 5);
		cMat.setArray(matC.transpose());
		btc.setArray((matB.multiply(cMat)).getArray());
		btc.print();
		System.out.println();
		System.out.println();
		
/*Matrix C with Matrix D*/
		System.out.println("Multiplication of C with D ");
		SparseMatrix cd = new SparseMatrix(5,5);
		cd.setArray((matC.multiply(matD)).getArray());
		cd.print();
		System.out.println();
		System.out.println();
		
/*Matrix D with Matrix C*/
		System.out.println("Multiplication of D with C ");
		SparseMatrix dc = new SparseMatrix(5,5);
		dc.setArray((matD.multiply(matC)).getArray());
		dc.print();
		System.out.println();
		System.out.println();

/*Matrix E with Matrix F*/
		System.out.println("Multiplication of E with F ");
		SparseMatrix ef = new SparseMatrix(200,1);
		ef.setArray((matE.multiply(matF)).getArray());
		ef.print();
		System.out.println();
		System.out.println();
		
/*Multiply Matrix A with itself and Matrix E with itself*/	
		System.out.println("Multiplication of A with itself ");
		a.setArray((matA.multiply(matA)).getArray());
		a.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Multiplication of E with itself ");
		e.setArray((matE.multiply(matE)).getArray());
		e.print();
		System.out.println();
		System.out.println();
		

		final long multiplicationDuration = System.nanoTime() - multiplicationTime;
/*For Matrices A and E raise each matrix to the power of 5 and 25 using power().*/
		final long powerTime = System.nanoTime();
		System.out.println("Power of A to 5 ");
		a.setArray(matA.power(5));
		a.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Power of A to 25 ");
		a.setArray(matA.power(25));
		a.print();
		System.out.println();
		System.out.println();
		
//		System.out.println("Power of E to 5 ");
//		e.setArray(matE.power(5));
//		e.print();
//		System.out.println();
//		System.out.println();
//		
//		System.out.println("Power of E to 25 ");
//		e.setArray(matE.power(25));
//		e.print();
//		System.out.println();
//		System.out.println();
//		
		final long powerDuration = System.nanoTime() - powerTime;
/*Compute the transpose of each matrix and print the result.*/	
		final long transposeTime = System.nanoTime();
		System.out.println("Transpose of A ");
		a.setArray(matA.transpose());
		a.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Transpose of B ");
		SparseMatrix b1 = new SparseMatrix(6, 4);
		b1.setArray(matB.transpose());
		b1.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Transpose of C ");
		SparseMatrix c1 = new SparseMatrix(6, 5);
		c1.setArray(matC.transpose());
		c1.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Transpose of D ");
		SparseMatrix d1 = new SparseMatrix(5, 6);
		d1.setArray(matD.transpose());
		d1.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Transpose of E ");
		e.setArray(matE.transpose());
		e.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Transpose of F ");
		SparseMatrix f1 = new SparseMatrix(1, 200);
		f1.setArray(matF.transpose());
		f1.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Transpose of G ");
		g.setArray(matG.transpose());
		g.print();
		System.out.println();
		System.out.println();
		final long transposeDuration = System.nanoTime() - transposeTime;
		
/*Multiply each matrix with its transpose and its transpose with itself. Print the result for each*/
		final long transposemultTime = System.nanoTime();
		
		System.out.println("Multiplication of A with its transpose ");
		a.setArray(matA.transpose());
		a.setArray((matA.multiply(a)).getArray());
		a.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Multiplication of B with its transpose ");
		SparseMatrix btb = new SparseMatrix(4, 4);
		SparseMatrix bs = new SparseMatrix(4, 6);
		bs.setArray(matB.transpose());
		bs.setM(matB.getN());
		bs.setN(matB.getM());
		btb.setArray((matB.multiply(bs)).getArray());
		btb.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Multiplication of C with its transpose ");
		SparseMatrix ctc = new SparseMatrix(5,5);
		SparseMatrix cs = new SparseMatrix(5, 6);
		cs.setArray(matC.transpose());
		cs.setM(matC.getN());
		cs.setN(matC.getM());
		ctc.setArray((matC.multiply(cs)).getArray());
		ctc.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Multiplication of D with its transpose ");
		SparseMatrix dtd = new SparseMatrix(5,5);
		SparseMatrix ds = new SparseMatrix(6, 5);
		ds.setArray(matD.transpose());
		ds.setM(matD.getN());
		ds.setN(matD.getM());
		dtd.setArray((matD.multiply(ds)).getArray());
		dtd.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Multiplication of E with its transpose ");
		e.setArray(matE.transpose());
		e.setArray((matE.multiply(e)).getArray());
		e.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Multiplication of F with its transpose ");
		SparseMatrix ftf= new SparseMatrix(1, 1);
		SparseMatrix fs=new SparseMatrix(200,1);
		fs.setArray(matF.transpose());
		fs.setM(matF.getN());
		fs.setN(matF.getM());
		ftf.setArray((matF.multiply(fs)).getArray());
		ftf.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Multiplication of transpose of A with A ");
		a.setArray(matA.transpose());
		a.setArray((a.multiply(matA)).getArray());
		a.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Multiplication of transpose of B with B ");
		bs.setArray(matB.transpose());
		bs.setM(matB.getN());
		bs.setN(matB.getM());
		btb.setArray((bs.multiply(matB)).getArray());
		btb.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Multiplication of transpose of C with C ");
		cs.setArray(matC.transpose());
		cs.setM(matC.getN());
		cs.setN(matC.getM());
		ctc.setArray((cs.multiply(matC)).getArray());
		ctc.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Multiplication of transpose of D with D ");
		ds.setArray(matD.transpose());
		ds.setM(matD.getN());
		ds.setN(matD.getM());
		dtd.setArray((ds.multiply(matD)).getArray());
		dtd.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Multiplication of transpose of E with E ");
		e.setArray(matE.transpose());
		e.setArray((e.multiply(matE)).getArray());
		e.print();
		System.out.println();
		System.out.println();
		
		System.out.println("Multiplication of transpose F with F ");
		fs.setArray(matF.transpose());
		fs.setM(matF.getN());
		fs.setN(matF.getM());
		ftf.setArray((fs.multiply(matF)).getArray());
		ftf.print();
		System.out.println();
		System.out.println();
		
		final long transposemultDuration = System.nanoTime() - transposemultTime;
		final long totalDuration = System.nanoTime() - totalTime;		
/*Compute the running time for each individual test case in Step 2 (e.g., each time you call add, subtract, or
multiply for a test case, determine its running time in nanoseconds (Java) or ticks (C++).*/		
		System.out.println("Addition Time"+" "+addDuration+" "+"nanoseconds");
		System.out.println("Subtraction Time"+" "+subDuration+" "+"nanoseconds");
		System.out.println("5M-M Time"+" "+scalarSubDuration+" "+"nanoseconds");
		System.out.println("Power Time"+" "+powerDuration+" "+"nanoseconds");
		System.out.println("Transpose Time"+" "+transposeDuration+" "+"nanoseconds");
		System.out.println("Multiplication Time"+" "+multiplicationDuration+" "+"nanoseconds");
		System.out.println("Transpose Multiplication Time"+" "+transposemultDuration+" "+"nanoseconds");
		System.out.println();
		System.out.println("TOTAL EXECUTION TIME: "+" "+totalDuration+" "+"nanoseconds");
		
	}

}
